public class Buffer {
    private PageID pageId;
    private byte[] pageData;
    private int pinCount;
    private boolean dirty;
    private long lastAccessTime;

    public Buffer(int pageSize) {
        this.pageId = null;
        this.pageData = new byte[pageSize];
        this.pinCount = 0;
        this.dirty = false;
        this.lastAccessTime = System.currentTimeMillis();
    }

    public PageID getPageId() {
        return pageId;
    }

    public void setPageId(PageID pageId) {
        this.pageId = pageId;
        this.updateLastAccessTime();
    }

    public byte[] getPageData() {
        return pageData;
    }

    public void setPageData(byte[] pageData) {
        this.pageData = pageData;
        this.updateLastAccessTime();
    }

    public int getPinCount() {
        return pinCount;
    }

    public void incrementPinCount() {
        pinCount++;
        this.updateLastAccessTime();
    }

    public void decrementPinCount() {
        if (pinCount > 0) {
            pinCount--;
        }
        this.updateLastAccessTime();
    }

    public void resetPinCount() {
        this.pinCount = 0;
    }

    public boolean isDirty() {
        return dirty;
    }

    public void setDirty(boolean dirty) {
        this.dirty = dirty;
    }

    public long getLastAccessTime() {
        return lastAccessTime;
    }

    private void updateLastAccessTime() {
        this.lastAccessTime = System.currentTimeMillis();
    }

    public void reset() {
        this.pageId = null;
        this.pageData = new byte[pageData.length];
        this.pinCount = 0;
        this.dirty = false;
        this.updateLastAccessTime();
    }
}