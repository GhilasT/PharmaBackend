import java.util.ArrayList;

public class Record {
    private ArrayList<String> listeInfo;

    public Record() {
        this.listeInfo = new ArrayList<>();
    }

    public int getSize() {
        return listeInfo.size();
    }

    public String getValue(int index) {
        if (index < 0 || index >= listeInfo.size()) {
            throw new IndexOutOfBoundsException("Index invalide pour le record : " + index);
        }
        return listeInfo.get(index);
    }

    public void addValue(int index, String element) {
        if (index < 0 || index > listeInfo.size()) {
            throw new IndexOutOfBoundsException("Index invalide pour ajouter une valeur : " + index);
        }
        if (index == listeInfo.size()) {
            listeInfo.add(element);
        }
    }
}