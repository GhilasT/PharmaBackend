public class ColInfo {
    private String nomColonne;
	private String typeColonne;

    public ColInfo(String nomColonne, String typeColonne) {
        this.nomColonne = nomColonne;
        this.typeColonne = typeColonne;
    }

    public String getNomColonne() {
        return nomColonne;
    }

    public void setNomColonne(String nomColonne) {
        this.nomColonne = nomColonne;
    }

    public String getTypeColonne() {
        return typeColonne;
    }

    public void setTypeColonne(String typeColonne) {
        this.typeColonne = typeColonne;
    }


    

    
}