import java.io.FileWriter;
import org.json.JSONObject;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class DiskManager {
    private DBConfig config;
    private int Xfichier;
    private int indicPage;
    private int tailleActuFich;
    private ArrayList<PageID> page_libre;

    public DiskManager(DBConfig config) {
        this.config = config;
        this.Xfichier = 0;
        this.indicPage = 0;
        this.tailleActuFich = 0;
        this.page_libre = new ArrayList<>();
    }

    public PageID AllocPage() {
        if (!page_libre.isEmpty()) {
            return page_libre.remove(page_libre.size() - 1);
        }

        if (tailleActuFich + config.getPagesize() > config.getDM_maxfilesize()) {
            Xfichier++;
            tailleActuFich = 0;
            indicPage = 0;
        }

        PageID page = new PageID(Xfichier, indicPage);
        indicPage++;
        tailleActuFich += config.getPagesize();
        page.setPagesize(config.getPagesize());
        return page;
    }

    public void DeallocPage(PageID page) {
        if (!page_libre.contains(page)) {
            page_libre.add(page);
        }
    }

    public void SaveState() throws IOException {
        JSONArray jsonArray = new JSONArray();
        for (PageID pg : page_libre) {
            JSONObject pageObject = new JSONObject();
            pageObject.put("FileIdx", pg.getFileIdx());
            pageObject.put("PageIdx", pg.getPageIdx());
            jsonArray.put(pageObject);
        }

        String jsonString = jsonArray.toString(4);
        String filechemin = config.getDbpath() + "/dm_save.json";

        try (FileWriter writer = new FileWriter(filechemin)) {
            writer.write(jsonString);
        }
    }

    public void LoadState() throws IOException {
        String filechemin = config.getDbpath() + "/dm_save.json";
        String json = new String(Files.readAllBytes(Paths.get(filechemin)));
        JSONArray jsonArray = new JSONArray(json);

        page_libre.clear();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pageObject = jsonArray.getJSONObject(i);
            int fileIdx = pageObject.getInt("FileIdx");
            int pageIdx = pageObject.getInt("PageIdx");
            page_libre.add(new PageID(fileIdx, pageIdx));
        }
    }

    public void ReadPage(PageID page, ByteBuffer buff) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile("F" + page.getFileIdx() + ".rsdb", "r")) {
            file.seek(page.getPageIdx() * config.getPagesize());
            byte[] data = new byte[config.getPagesize()];
            file.readFully(data);
            buff.clear();
            buff.put(data);
            buff.flip();
        }
    }

    public void WritePage(PageID page, ByteBuffer buff) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile("F" + page.getFileIdx() + ".rsdb", "rw")) {
            file.seek(page.getPageIdx() * config.getPagesize());
            byte[] data = new byte[config.getPagesize()];
            buff.get(data);
            buff.flip();
            file.write(data);
        }
    }
}
