public class MainTest {
    public static void main(String[] args) {
        DBConfig config = new DBConfig(null, 0, 0, 0, 0);
        // Testez les fonctionnalités ici
        System.out.println("DBConfig testé !");
    }
}