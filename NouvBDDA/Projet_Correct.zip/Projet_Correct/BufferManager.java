import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;

public class BufferManager {
    DBConfig config;
    private DiskManager disk;
    private ArrayList<Buffer> buffListe;
    private String currentReplacementPolicy;

    public BufferManager(DBConfig config, DiskManager disk) {
        this.config = config;
        this.disk = disk;
        this.buffListe = new ArrayList<>();
        for (int i = 0; i < config.getBm_buffercount(); i++) {
            buffListe.add(new Buffer(config.getPagesize()));
        }
        this.currentReplacementPolicy = "LRU"; // Par défaut
    }

    public ByteBuffer GetPage(PageID pageId) throws Exception {
        for (Buffer buffer : buffListe) {
            if (buffer.getPageId() != null && buffer.getPageId().equals(pageId)) {
                buffer.incrementPinCount();
                return ByteBuffer.wrap(buffer.getPageData());
            }
        }

        Buffer bufferToReplace = findBufferToReplace();
        if (bufferToReplace == null) {
            throw new IOException("Pas de buffer libre disponible !");
        }

        ByteBuffer tempBuffer = ByteBuffer.allocate(config.getPagesize());
        disk.ReadPage(pageId, tempBuffer);

        bufferToReplace.setPageData(tempBuffer.array());
        bufferToReplace.setPageId(pageId);
        bufferToReplace.setDirty(false);
        bufferToReplace.incrementPinCount();

        return ByteBuffer.wrap(bufferToReplace.getPageData());
    }

    public void FreePage(PageID pageId, boolean valdirty) {
        for (Buffer buffer : buffListe) {
            if (buffer.getPageId() != null && buffer.getPageId().equals(pageId)) {
                buffer.decrementPinCount();
                buffer.setDirty(valdirty);
                return;
            }
        }
    }

    public void SetCurrentReplacementPolicy(String policy) {
        if (policy.equals("LRU") || policy.equals("MRU")) {
            this.currentReplacementPolicy = policy;
            System.out.println("Politique de remplacement changée : " + policy);
        } else {
            throw new IllegalArgumentException("Politique inconnue : " + policy);
        }
    }

    public void FlushBuffers() throws Exception {
        for (Buffer buffer : buffListe) {
            if (buffer.isDirty() && buffer.getPinCount() == 0) {
                disk.WritePage(buffer.getPageId(), ByteBuffer.wrap(buffer.getPageData()));
                buffer.setDirty(false);
            }
            buffer.reset();
        }
    }

    private Buffer findBufferToReplace() {
        if (currentReplacementPolicy.equals("LRU")) {
            return buffListe.stream()
                    .filter(buffer -> buffer.getPinCount() == 0)
                    .min((b1, b2) -> Long.compare(b1.getLastAccessTime(), b2.getLastAccessTime()))
                    .orElse(null);
        } else if (currentReplacementPolicy.equals("MRU")) {
            return buffListe.stream()
                    .filter(buffer -> buffer.getPinCount() == 0)
                    .max((b1, b2) -> Long.compare(b1.getLastAccessTime(), b2.getLastAccessTime()))
                    .orElse(null);
        }
        return null;
    }
}