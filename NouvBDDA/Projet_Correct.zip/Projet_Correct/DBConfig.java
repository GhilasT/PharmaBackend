import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class DBConfig {
    private String dbpath;
    private int pagesize;
    private int dm_maxfilesize;
    private int bm_buffercount;
    private int bm_policy;

    public DBConfig(String dbpath, int pagesize, int dm_maxfilesize, int bm_buffercount, int bm_policy) {
        this.dbpath = dbpath;
        this.pagesize = pagesize;
        this.dm_maxfilesize = dm_maxfilesize;
        this.bm_buffercount = bm_buffercount;
        this.bm_policy = bm_policy;
    }

    public String getDbpath() { return dbpath; }
    public int getPagesize() { return pagesize; }
    public int getDM_maxfilesize() { return dm_maxfilesize; }
    public int getBm_buffercount() { return bm_buffercount; }
    public int getBm_policy() { return bm_policy; }

    public static DBConfig LoadDBConfig(File fichier_config) throws IOException {
        try {
            String jsonString = new String(Files.readAllBytes(Paths.get(fichier_config.getPath())));
            JSONObject jsonObject = new JSONObject(jsonString);

            String dbpath = jsonObject.getString("dbpath");
            int pagesize = jsonObject.getInt("pagesize");
            int dm_maxfilesize = jsonObject.getInt("dm_maxfilesize");
            int bm_buffercount = jsonObject.getInt("bm_buffercount");
            int bm_policy = jsonObject.getInt("bm_policy");

            return new DBConfig(dbpath, pagesize, dm_maxfilesize, bm_buffercount, bm_policy);
        } catch (IOException e) {
            throw new IOException("Erreur lors de la lecture du fichier de configuration : " + e.getMessage());
        } catch (Exception e) {
            throw new IllegalArgumentException("Le fichier de configuration est invalide : " + e.getMessage());
        }
    }
}