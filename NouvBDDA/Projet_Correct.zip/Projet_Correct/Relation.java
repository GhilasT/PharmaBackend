import java.nio.ByteBuffer;
import java.util.ArrayList;

public class Relation {
    private String nom;
    private int nbColonnes;
    private ArrayList<ColInfo> colonnes;
    private PageID headerPageId;
    private DiskManager diskManager;
    private BufferManager bufferManager;

    public Relation(String nom, int nbColonnes, PageID headerPageId, DiskManager diskManager, BufferManager bufferManager) {
        this.nom = nom;
        this.nbColonnes = nbColonnes;
        this.colonnes = new ArrayList<>();
        this.headerPageId = headerPageId;
        this.diskManager = diskManager;
        this.bufferManager = bufferManager;
    }

    public void initialiserListeColonne(ColInfo colInfo) {
        colonnes.add(colInfo);
    }

    public void addDataPage() throws Exception {
        PageID newPage = diskManager.AllocPage();
        ByteBuffer headerBuffer = bufferManager.GetPage(headerPageId);

        int numPages = headerBuffer.getInt(0); // Nombre actuel de pages
        int headerPageCapacity = (bufferManager.config.getPagesize() - 8) / 12;

        if (numPages >= headerPageCapacity) {
            // Si la Header Page est pleine, créez une nouvelle page de directory
            PageID newHeaderPage = diskManager.AllocPage();
            headerBuffer.putInt(bufferManager.config.getPagesize() - 4, newHeaderPage.getPageIdx());
            bufferManager.FreePage(headerPageId, true);
            headerPageId = newHeaderPage;
            headerBuffer = bufferManager.GetPage(headerPageId);
            headerBuffer.putInt(0, 0); // Initialiser le nombre de pages à 0
        }

        int offset = 4 + numPages * 12;
        headerBuffer.putInt(offset, newPage.getFileIdx());
        headerBuffer.putInt(offset + 4, newPage.getPageIdx());
        headerBuffer.putInt(offset + 8, bufferManager.config.getPagesize());

        headerBuffer.putInt(0, numPages + 1); // Incrémenter le nombre de pages
        bufferManager.FreePage(headerPageId, true);
    }

    public PageID getFreeDataPageId(int sizeRecord) throws Exception {
        PageID currentHeader = headerPageId;

        while (currentHeader != null) {
            ByteBuffer headerBuffer = bufferManager.GetPage(currentHeader);
            int numPages = headerBuffer.getInt(0);

            for (int i = 0; i < numPages; i++) {
                int offset = 4 + i * 12;
                int availableSpace = headerBuffer.getInt(offset + 8);

                if (availableSpace >= sizeRecord) {
                    int fileIdx = headerBuffer.getInt(offset);
                    int pageIdx = headerBuffer.getInt(offset + 4);
                    bufferManager.FreePage(currentHeader, false);
                    return new PageID(fileIdx, pageIdx);
                }
            }

            int nextHeaderPageIdx = headerBuffer.getInt(bufferManager.config.getPagesize() - 4);
            currentHeader = (nextHeaderPageIdx != 0) ? new PageID(currentHeader.getFileIdx(), nextHeaderPageIdx) : null;
            bufferManager.FreePage(currentHeader, false);
        }

        return null;
    }

    public RecordId writeRecordToDataPage(Record record, PageID pageId) throws Exception {
        ByteBuffer dataBuffer = bufferManager.GetPage(pageId);

        int freeSpaceOffset = dataBuffer.getInt(0);
        int numSlots = dataBuffer.getInt(4);

        int recordSize = calculateRecordSize(record);
        int recordPosition = freeSpaceOffset - recordSize;

        dataBuffer.position(recordPosition);
        writeRecordToBuffer(record, dataBuffer);

        dataBuffer.putInt(0, recordPosition); // Mettre à jour l'espace libre
        dataBuffer.putInt(4, numSlots + 1); // Incrémenter le nombre de slots

        int slotOffset = bufferManager.config.getPagesize() - 8 - (numSlots * 8);
        dataBuffer.putInt(slotOffset, recordPosition);
        dataBuffer.putInt(slotOffset + 4, recordSize);

        bufferManager.FreePage(pageId, true);

        return new RecordId(pageId, numSlots);
    }

    public ArrayList<Record> getRecordsInDataPage(PageID pageId) throws Exception {
        ArrayList<Record> records = new ArrayList<>();
        ByteBuffer dataBuffer = bufferManager.GetPage(pageId);

        int numSlots = dataBuffer.getInt(4);

        for (int i = 0; i < numSlots; i++) {
            int slotOffset = bufferManager.config.getPagesize() - 8 - (i * 8);
            int recordPosition = dataBuffer.getInt(slotOffset);
            int recordSize = dataBuffer.getInt(slotOffset + 4);

            if (recordSize > 0) {
                ByteBuffer recordBuffer = ByteBuffer.allocate(recordSize);
                dataBuffer.position(recordPosition);
                dataBuffer.get(recordBuffer.array());

                Record record = readFromBuffer(recordBuffer);
                records.add(record);
            }
        }

        bufferManager.FreePage(pageId, false);
        return records;
    }

    public ArrayList<PageID> getDataPages() throws Exception {
        ArrayList<PageID> pageIds = new ArrayList<>();
        PageID currentHeader = headerPageId;

        while (currentHeader != null) {
            ByteBuffer headerBuffer = bufferManager.GetPage(currentHeader);
            int numPages = headerBuffer.getInt(0);

            for (int i = 0; i < numPages; i++) {
                int offset = 4 + i * 12;
                int fileIdx = headerBuffer.getInt(offset);
                int pageIdx = headerBuffer.getInt(offset + 4);
                pageIds.add(new PageID(fileIdx, pageIdx));
            }

            int nextHeaderPageIdx = headerBuffer.getInt(bufferManager.config.getPagesize() - 4);
            currentHeader = (nextHeaderPageIdx != 0) ? new PageID(currentHeader.getFileIdx(), nextHeaderPageIdx) : null;
            bufferManager.FreePage(currentHeader, false);
        }

        return pageIds;
    }

    public RecordId InsertRecord(Record record) throws Exception {
        int recordSize = calculateRecordSize(record);
        PageID pageId = getFreeDataPageId(recordSize);

        if (pageId == null) {
            addDataPage();
            pageId = getFreeDataPageId(recordSize);
        }

        return writeRecordToDataPage(record, pageId);
    }

    public ArrayList<Record> GetAllRecords() throws Exception {
        ArrayList<Record> allRecords = new ArrayList<>();
        ArrayList<PageID> dataPages = getDataPages();

        for (PageID pageId : dataPages) {
            allRecords.addAll(getRecordsInDataPage(pageId));
        }

        return allRecords;
    }

    private int calculateRecordSize(Record record) {
        int size = 0;
        for (int i = 0; i < record.getSize(); i++) {
            ColInfo colInfo = colonnes.get(i);
            switch (colInfo.getTypeColonne()) {
                case "INT":
                    size += Integer.BYTES;
                    break;
                case "FLOAT":
                    size += Float.BYTES;
                    break;
                case "STRING":
                    size += 100; // Taille fixe pour les chaînes
                    break;
            }
        }
        return size;
    }

    private void writeRecordToBuffer(Record record, ByteBuffer buffer) {
        for (int i = 0; i < record.getSize(); i++) {
            ColInfo colInfo = colonnes.get(i);
            switch (colInfo.getTypeColonne()) {
                case "INT":
                    buffer.putInt(Integer.parseInt(record.getValue(i)));
                    break;
                case "FLOAT":
                    buffer.putFloat(Float.parseFloat(record.getValue(i)));
                    break;
                case "STRING":
                    byte[] stringBytes = record.getValue(i).getBytes();
                    buffer.put(stringBytes, 0, Math.min(stringBytes.length, 100));
                    break;
            }
        }
    }

    private Record readFromBuffer(ByteBuffer buffer) {
        Record record = new Record();
        for (ColInfo colInfo : colonnes) {
            switch (colInfo.getTypeColonne()) {
                case "INT":
                    record.addValue(record.getSize(), String.valueOf(buffer.getInt()));
                    break;
                case "FLOAT":
                    record.addValue(record.getSize(), String.valueOf(buffer.getFloat()));
                    break;
                case "STRING":
                    byte[] stringBytes = new byte[100];
                    buffer.get(stringBytes);
                    record.addValue(record.getSize(), new String(stringBytes).trim());
                    break;
            }
        }
        return record;
    }
}