package l3o2.pharmacie.api.model.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FournisseurCreateRequest {

    @NotBlank(message = "Le nom de la société est obligatoire")
    @Size(max = 100, message = "Le nom de la société ne peut pas dépasser 100 caractères")
    private String societe;

    @NotBlank(message = "Le contact est obligatoire")
    @Size(max = 50, message = "Le nom du contact ne peut pas dépasser 50 caractères")
    private String nom;
    
    @NotBlank(message = "Le contact est obligatoire")
    @Size(max = 50, message = "Le nom du contact ne peut pas dépasser 50 caractères")
    private String prenom;

    private String sujetFonction;

    @NotBlank(message = "Le téléphone est obligatoire")
    @Pattern(regexp = "^(\\+?[0-9]{6,15})$", message = "Le numéro de téléphone doit contenir entre 6 et 15 chiffres")
    private String telephone;

    @Pattern(regexp = "^(\\+?[0-9]{6,15})?$", message = "Le fax doit contenir entre 6 et 15 chiffres ou être vide")
    private String fax;

    @NotBlank(message = "L'adresse est obligatoire")
    @Size(max = 255, message = "L'adresse ne peut pas dépasser 255 caractères")
    private String adresse;

    @NotBlank(message = "L'email est obligatoire")
    @Email(message = "L'email doit être valide")
    private String email;
}